class MessageModel {
  String? type;
  String? message;
  String? time;
  MessageModel({this.message, this.type, this.time});
}
