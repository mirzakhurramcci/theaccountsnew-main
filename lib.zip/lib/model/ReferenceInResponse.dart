class RefrenceInResponse {
  RefrenceInResponseData? data;
  String? message;
  List<String>? errorList;

  RefrenceInResponse({this.data, this.message, this.errorList});

  RefrenceInResponse.fromJson(Map<String, dynamic> json) {
    data = json['Data'] != null
        ? new RefrenceInResponseData.fromJson(json['Data'])
        : null;
    message = json['Message'];
    errorList = json['ErrorList'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    data['Message'] = this.message;
    data['ErrorList'] = this.errorList;
    return data;
  }
}

class RefrenceInResponseData {
  double? accumulatedCapital;
  int? totalMembers;
  double? totalMemberClosing;
  List<RefInData>? refInData;

  RefrenceInResponseData(
      {this.accumulatedCapital,
      this.totalMembers,
      this.totalMemberClosing,
      this.refInData});

  RefrenceInResponseData.fromJson(Map<String, dynamic> json) {
    accumulatedCapital = json['AccumulatedCapital'];
    totalMembers = json['TotalMembers'];
    totalMemberClosing = json['TotalMemberClosing'];
    if (json['RefInData'] != null) {
      refInData = <RefInData>[];
      json['RefInData'].forEach((v) {
        refInData!.add(new RefInData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['AccumulatedCapital'] = this.accumulatedCapital;
    data['TotalMembers'] = this.totalMembers;
    data['TotalMemberClosing'] = this.totalMemberClosing;
    if (this.refInData != null) {
      data['RefInData'] = this.refInData!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class RefInData {
  double? capitalAmount;
  double? closingAmount;
  String? fullName;
  String? userName;
  String? date;
  String? dateStr;
  int? profileId;

  RefInData(
      {this.capitalAmount,
      this.closingAmount,
      this.fullName,
      this.userName,
      this.date,
      this.dateStr,
      this.profileId});

  RefInData.fromJson(Map<String, dynamic> json) {
    capitalAmount = json['CapitalAmount'];
    closingAmount = json['ClosingAmount'];
    fullName = json['FullName'];
    userName = json['UserName'];
    date = json['Date'];
    dateStr = json['DateStr'];
    profileId = json['ProfileId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['CapitalAmount'] = this.capitalAmount;
    data['ClosingAmount'] = this.closingAmount;
    data['FullName'] = this.fullName;
    data['UserName'] = this.userName;
    data['Date'] = this.date;
    data['DateStr'] = this.dateStr;
    data['ProfileId'] = this.profileId;
    return data;
  }
}
