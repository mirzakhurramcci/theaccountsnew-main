abstract class BaseBloc {
  void dispose();
}