import 'package:theaccounts/model/CapitalHistoryResponse.dart';
import 'package:theaccounts/model/ClosingRatioResponse.dart';
import 'package:theaccounts/model/DashboardResponse.dart';
import 'package:theaccounts/model/GalleryResponse.dart';
import 'package:theaccounts/model/MessageHistoryResponse.dart';
import 'package:theaccounts/model/PaymentDetailResponse.dart';
import 'package:theaccounts/model/ReceivedAmountResponse.dart';
import 'package:theaccounts/model/ReferenceInResponse.dart';
import 'package:theaccounts/model/SendNotificationResponse.dart';
import 'package:theaccounts/model/ClosingPaymentResponse.dart';
import 'package:theaccounts/model/UpdateBankResponse.dart';
import 'package:theaccounts/model/UpdateProfileResponse.dart';
import 'package:theaccounts/model/WithdrawResponse.dart';
import 'package:theaccounts/model/requestbody/HistoryReqBody.dart';
import 'package:theaccounts/model/requestbody/PaymentHistoryReqBody.dart';
import 'package:theaccounts/model/requestbody/ReceivePaymentReqBody.dart';
import 'package:theaccounts/model/requestbody/ReceivedAmountReqBody.dart';
import 'package:theaccounts/model/requestbody/SaveMessageReqBody.dart';
import 'package:theaccounts/model/requestbody/UpdateBankReqBody.dart';
import 'package:theaccounts/model/requestbody/UpdateProfileReqBody.dart';
import 'package:theaccounts/model/requestbody/WithdrawReqBody.dart';
import 'package:theaccounts/networking/ApiBaseHelper.dart';
import 'package:theaccounts/networking/Endpoints.dart';
import 'package:theaccounts/repositories/BaseRepository.dart';

class DashboardRepository extends BaseRepository {
  ApiBaseHelper _helper = ApiBaseHelper();

  Future<DashboardResponse> GetDashboardData() async {
    final response = await _helper.get(Endpoints.DashboardDataUrl);
    return DashboardResponse.fromJson(response);
  }

  Future<WithdrawResponse> GetWithdrawalData() async {
    final response = await _helper.get(Endpoints.WithdrawDataUrl);
    return WithdrawResponse.fromJson(response);
  }

  Future<WithdrawResponse> SaveWithdrawalData(WithdrawReqBody reqBody) async {
    final response = await _helper.post(Endpoints.SaveWithDrawUrl, reqBody);
    var resp = WithdrawResponse.fromJson(response);
    return resp;
  }

  Future<UpdateProfileResponse> GetProfileData() async {
    final response = await _helper.get(Endpoints.ProfileDataUrl);
    return UpdateProfileResponse.fromJson(response);
  }

  Future<UpdateProfileResponse> GetProfileViewData(int profileid) async {
    final response = await _helper.get(
        Endpoints.ProfileViewDataUrl + "?profileId=" + profileid.toString());
    return UpdateProfileResponse.fromJson(response);
  }

  Future<UpdateProfileResponse> SaveProfileData(
      UpdateProfileReqBody reqBody) async {
    final response = await _helper.post(Endpoints.SaveProfileUrl, reqBody);
    var resp = UpdateProfileResponse.fromJson(response);
    return resp;
  }

  Future<dynamic> SaveProfilePicture(String path) async {
    final response = await _helper.postProfilePic(Endpoints.uploadPicUrl, path);
    return response;
  }

  Future<UpdateBankResponse> GetBankData() async {
    final response = await _helper.get(Endpoints.BankDataUrl);
    return UpdateBankResponse.fromJson(response);
  }

  Future<UpdateBankResponse> SaveBankData(UpdateBankReqBody reqBody) async {
    final response = await _helper.post(Endpoints.SaveBankUrl, reqBody);
    var resp = UpdateBankResponse.fromJson(response);
    return resp;
  }

  Future<ClosingPaymentResponse> GetPaymentRolloverData() async {
    final response = await _helper.get(Endpoints.PaymentRolloverDataUrl);
    return ClosingPaymentResponse.fromJson(response);
  }

  Future<ClosingPaymentResponse> SavePaymentRollover(
      ReceivePaymentReqBody reqBody) async {
    final response =
        await _helper.post(Endpoints.SavePaymeyRolloverUrl, reqBody);
    var resp = ClosingPaymentResponse.fromJson(response);
    return resp;
  }

  Future<ClosingPaymentResponse> SaveRollover(
      ReceivePaymentReqBody reqBody) async {
    final response = await _helper.post(Endpoints.SaveRolloverUrl, reqBody);
    var resp = ClosingPaymentResponse.fromJson(response);
    return resp;
  }

  Future<ClosingRatioResponse> GetClosingRatioData() async {
    final response = await _helper.get(Endpoints.RatioUrl);
    return ClosingRatioResponse.fromJson(response);
  }

  Future<PaymentRolloverHistoryResponse> GetPaymentRolloveHistoryData(
      PaymentHistoryReqBody reqBody) async {
    final response =
        await _helper.post(Endpoints.PaymentRolloverHistoryUrl, reqBody);
    return PaymentRolloverHistoryResponse.fromJson(response);
  }

  // Future<CapitalHistoryResponse> GetCapitalHistoryData() async {
  //   final response = await _helper.get(Endpoints.CapitalHistoryRequestGet);
  //   return CapitalHistoryResponse.fromJson(response);
  // }

  Future<CapitalHistoryResponse> GetCapitalHistoryData(
      HistoryReqBody reqBody) async {
    final response = await _helper.post(Endpoints.CapitalHistoryUrl, reqBody);
    var resp = CapitalHistoryResponse.fromJson(response);
    return resp;
  }
  //GetLastAddedAmountyData

  Future<CapitalHistoryResponse> GetLastAddedAmountyData(
      HistoryReqBody reqBody) async {
    final response =
        await _helper.post(Endpoints.LastAddAmountHistoryUrl, reqBody);
    var resp = CapitalHistoryResponse.fromJson(response);
    return resp;
  }

  Future<ReceivedAmountResponse> GetReceivedAmount(
      ReceivedAmountReqBody reqBody) async {
    final response = await _helper.post(Endpoints.ReceivedAmountUrl, reqBody);
    var resp = ReceivedAmountResponse.fromJson(response);
    return resp;
  }

  Future<SendNotificationResponse> GetNotificationData() async {
    final response = await _helper.get(Endpoints.NotificationUrl);
    return SendNotificationResponse.fromJson(response);
  }

  Future<RefrenceInResponse> PostReferenceInData(
      HistoryReqBody reqBody, String? query) async {
    final response = await _helper.post(Endpoints.SaveReferenceInUrl, reqBody);
    var resp = RefrenceInResponse.fromJson(response);
    return resp;
  }

  Future<MessageHistoryResponse> GetMessageHistoryData() async {
    final response = await _helper.get(Endpoints.MessageHistoryUrl);
    return MessageHistoryResponse.fromJson(response);
  }

  Future<MessageHistoryResponse> SaveMessageData(
      SaveMessageReqBody reqBody) async {
    final response = await _helper.post(Endpoints.SaveMessageUrl, reqBody);
    var resp = MessageHistoryResponse.fromJson(response);
    return resp;
  }

  Future<GalleryResponse> GetGalleryData() async {
    final response = await _helper.get(Endpoints.galleryUrl);
    return GalleryResponse.fromJson(response);
  }
}
