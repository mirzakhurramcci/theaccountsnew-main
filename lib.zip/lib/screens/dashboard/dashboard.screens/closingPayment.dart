import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:theaccounts/ScopedModelWrapper.dart';
import 'package:theaccounts/bloc/dashboard_bloc.dart';
import 'package:theaccounts/model/ClosingPaymentResponse.dart';
import 'package:theaccounts/model/requestbody/ReceivePaymentReqBody.dart';
import 'package:theaccounts/networking/ApiResponse.dart';
import 'package:theaccounts/screens/dashboard/custom.widgets/custom_widgets.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/alerts.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/hidecapital.screen.dart';
import 'package:theaccounts/screens/setting/components/setting.widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:theaccounts/screens/widgets/loading_dialog.dart';
import 'package:theaccounts/utils/Const.dart';
import 'package:theaccounts/utils/utility.dart';

import '../../../model/DashboardResponse.dart';
import 'transection_sheet.dart';

class ClosingPaymentScreen extends StatelessWidget {
  ClosingPaymentScreen({Key? key}) : super(key: key);
  static const routeName = '/closing_payment-screen';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Theme.of(context).cardColor,
        resizeToAvoidBottomInset: false,
        body: Padding(
          padding: const EdgeInsets.only(left: 10, right: 10),
          child: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(flex: 01, child: CustomTopBar(topbartitle: "")),
                Flexible(
                  flex: 09,
                  child: KeyboardVisibilityBuilder(builder: (context, visible) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: visible ? 200 : 12.0.h),
                      child: ClosingPaymentBottomSheet(),
                    );
                  }),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ClosingPaymentBottomSheet extends StatefulWidget {
  const ClosingPaymentBottomSheet({Key? key}) : super(key: key);

  @override
  State<ClosingPaymentBottomSheet> createState() =>
      _ClosingPaymentBottomSheetState();
}

class _ClosingPaymentBottomSheetState extends State<ClosingPaymentBottomSheet>
    with TickerProviderStateMixin {
  final _duration = Duration(milliseconds: 600);

  late AnimationController _animationcontroller;
  late Animation _animateopacity;
  late Animation<double> _animateleft;

  late TextEditingController _transfertextcontroller;
  late TextEditingController _rollovertextcontroller;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  late DashboardBloc _bloc;
  ClosingPaymentResponseData? data;
  DashboardResponseData Userdata =
      DashboardResponseData(IsRefrenceInAllowed: false);
  bool loaded = false;
  @override
  void initState() {
    _bloc = DashboardBloc();

    _bloc.GetPaymentRolloverStream.listen((event) {
      print(jsonEncode(event.data));
      if (event.status == Status.COMPLETED) {
        DialogBuilder(context).hideLoader();
        setState(() {
          data = event.data;
          print(data?.toJson());
        });
        if (data?.IsProfileRolloverEnable == false) {
          Navigator.pop(context);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ClosingPaymentAlert(
                      title: "Alert!",
                      message: "Closing Payment had \nbeen closed.")));
        } else if (data?.RoRequestStatus == "Pending") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ClosingTransectionSheet(
                      message: event.message,
                      title: "Your previous payment request is still Pending.",
                      response: event.data ?? ClosingPaymentResponseData())));
        } else {
          setState(() {
            loaded = true;
          });
        }
      } else if (event.status == Status.ERROR) {
        DialogBuilder(context).hideLoader();
        //showSnackBar(context, event.message, true);
        Navigator.pop(context);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ClosingPaymentAlert(
                    title: "Payment Error", message: event.message)));
      } else if (event.status == Status.LOADING) {
        DialogBuilder(context).showLoader();
      }
    });
    _bloc.GetPaymentRolloverData();
    _bloc.SavePaymentRolloverStream.listen((event) {
      print(jsonEncode(event.data));
      if (event.status == Status.COMPLETED) {
        DialogBuilder(context).hideLoader();
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ClosingTransectionSheet(
                  message: event.message, response: event.data)),
        );
      } else if (event.status == Status.ERROR) {
        DialogBuilder(context).hideLoader();
        Navigator.pop(context);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ClosingPaymentAlert(
                    title: "Payment Error", message: event.message)));
      } else if (event.status == Status.LOADING) {
        DialogBuilder(context).showLoader();
      }
    });

    _transfertextcontroller = TextEditingController();
    _rollovertextcontroller = TextEditingController();

    _animationcontroller =
        AnimationController(vsync: this, duration: _duration);

    _animateopacity = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
            parent: _animationcontroller, curve: Curves.fastOutSlowIn));
    _animateleft = Tween<double>(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: _animationcontroller, curve: Curves.fastOutSlowIn));

    _animationcontroller.forward();
    _transfertextcontroller.addListener(getLatestvalue);
    super.initState();
  }

  @override
  void dispose() {
    _animationcontroller.dispose();
    _transfertextcontroller.dispose();
    _rollovertextcontroller.dispose();
    super.dispose();
  }

  getLatestvalue() {
    setState(() {
      rollover_amt = (total_amount) -
          (double.tryParse(_transfertextcontroller.text) ?? 0.0);
      if (_transfertextcontroller == "" ||
          _transfertextcontroller.text.isEmpty) {
        _rollovertextcontroller.text = "";
        rollover_amt = 0.0;
      }
    });
  }

  var total_amount = 0.0;
  var transfer_amount = 0.0;
  double rollover_amt = 0.0;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    Size size = MediaQuery.of(context).size;

    total_amount = data?.ClosingPayment ?? 0.0;
    transfer_amount = double.tryParse(_transfertextcontroller.text) ?? 0.0;
    // var rollover_amount = double.tryParse(_rollovertextcontroller.text);
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return AnimatedBuilder(
        key: _scaffoldKey,
        animation: _animationcontroller.view,
        builder: (context, child) {
          if (!loaded) return Container();
          return Transform(
            transform:
                Matrix4.translationValues(0.0, _animateleft.value * width, 0.0),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12.0),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xffFF992E),
                      Color(0xffDA1467),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: SingleChildScrollView(
                  reverse: true,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: bottom),
                    child: Container(
                      height: size.height * 0.65,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 15.h,
                          ),
                          divider,
                          SizedBox(
                            height: 10.h,
                          ),
                          Text(
                            "Closing Payment",
                            style:
                                Theme.of(context).textTheme.headline6!.copyWith(
                                      fontSize: 18.sp,
                                      fontFamily: "Montserrat",
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white,
                                    ),
                          ),
                          SizedBox(height: 25.h),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                AnimatedOpacity(
                                  duration: _duration,
                                  opacity: _animateopacity.value,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Rs. ",
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6!
                                            .copyWith(
                                              fontSize: 20.sp,
                                              height: 2.0.h,
                                              fontFamily: "Montserrat",
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white,
                                            ),
                                      ),
                                      Text(
                                        Const.currencyFormatWithoutDecimal
                                            .format(data?.ClosingPayment ?? 0),
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6!
                                            .copyWith(
                                                fontSize: 36.sp,
                                                fontFamily: "Montserrat",
                                                fontWeight: FontWeight.w600,
                                                color: Colors.white),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20.h),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset(
                                        "assets/svg/total_transfer.svg"),
                                    SizedBox(
                                      width: 08.h,
                                    ),
                                    Text(
                                      "Transfer",
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall!
                                          .copyWith(
                                            fontSize: 15.sp,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: "Montserrat",
                                            color: Colors.white,
                                          ),
                                    ),
                                  ],
                                ),
                                AmountInputField(
                                  isBgColorWhite: true,
                                  textcontroller: _transfertextcontroller,
                                  hint: "",
                                  fontsize: 26.sp,
                                  color: [Colors.white, Colors.white],
                                ),
                                SizedBox(height: 20.h),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    AnimatedOpacity(
                                      duration: _duration,
                                      opacity: _animateopacity.value,
                                      child: Icon(
                                        Icons.settings_backup_restore_rounded,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 08.h,
                                    ),
                                    AnimatedOpacity(
                                      duration: _duration,
                                      opacity: _animateopacity.value,
                                      child: Text(
                                        "Rollover",
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall!
                                            .copyWith(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w600,
                                              fontFamily: 'Montserrat',
                                              color: Colors.white,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                                AmountInputField(
                                  isBgColorWhite: true,
                                  textcontroller: _rollovertextcontroller,
                                  hint: _transfertextcontroller.text.isEmpty
                                      ? ""
                                      : "$rollover_amt",
                                  isenable: false,
                                  fontsize: 26.h,
                                  color: [Colors.white, Colors.white],
                                ),
                                SizedBox(
                                  height: 29.h,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    print("$transfer_amount $rollover_amt");
                                    if (transfer_amount == 0.0 &&
                                        rollover_amt == 0.0) {
                                      showSnackBar(context,
                                          'Please enter a valid number.', true);
                                      return;
                                    } else if (transfer_amount > total_amount) {
                                      showSnackBar(
                                          context,
                                          'Transfer amount must be smeller then total amount.',
                                          true);
                                      return;
                                    }
                                    var data = ReceivePaymentReqData(
                                        rolloverAmount: rollover_amt,
                                        source: AppModel().deviceID(),
                                        transferAmount: transfer_amount);
                                    _bloc.SavePaymentRollover(data);
                                  },
                                  child: AnimatedLongButton(
                                    text: "Send".toUpperCase(),
                                    isBgColorWhite: true,
                                    color: [Colors.white, Colors.white],
                                  ),
                                ),
                                SizedBox(
                                  height: 20.h,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        });
  }

  ClosingTransectionSheet(
      {required String message,
      String? title,
      ClosingPaymentResponseData? response}) {
    return Transectiondetailwidget(
      DateStr: response?.RoRequestDate ?? "",
      Title: title ?? "Payment Request has been Processed",
      amountTypekey: "Transfer Amount",
      paymentTypekey: "Rollover",
      paymentTypevalue: Const.currencyFormatWithoutDecimal
          .format(response?.RoRequestAmount ?? 0),
      amountTypevalue: Const.currencyFormatWithoutDecimal
          .format(response?.TrRequestAmount ?? 0),
      onPressed: () {
        Navigator.pop(context);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => HideCapitalScreen(),
          ),
        );
      },
      color2: Color(0xffDA1467),
      color1: Color(0xffFF992E),
    );
  }
}

final divider = Divider(
  height: 8,
  color: Colors.white,
  endIndent: 150,
  indent: 150,
  thickness: 3.5,
);
