import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:theaccounts/ScopedModelWrapper.dart';
import 'package:theaccounts/bloc/dashboard_bloc.dart';
import 'package:theaccounts/model/ClosingPaymentResponse.dart';
import 'package:theaccounts/model/requestbody/ReceivePaymentReqBody.dart';
import 'package:theaccounts/networking/ApiResponse.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/alerts.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/hidecapital.screen.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/transection_sheet.dart';
import 'package:theaccounts/screens/setting/components/setting.widgets.dart';
import 'package:theaccounts/screens/widgets/loading_dialog.dart';
import 'package:theaccounts/utils/Const.dart';
import 'package:theaccounts/utils/utility.dart';

import '../../../model/DashboardResponse.dart';
import '../custom.widgets/custom_widgets.dart';

class RollOverScreen extends StatefulWidget {
  const RollOverScreen({Key? key}) : super(key: key);
  static const routeName = '/rollover-screen';

  @override
  State<RollOverScreen> createState() => _RollOverScreenState();
}

class _RollOverScreenState extends State<RollOverScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Material(
        child: Scaffold(
          // bottomNavigationBar: widgets.bottombar(context: context),
          backgroundColor: Theme.of(context).cardColor,
          resizeToAvoidBottomInset: false,
          body: Container(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(flex: 01, child: CustomTopBar(topbartitle: "")),
                Flexible(flex: 09, child: RollOverBottomSheet())
              ],
            ),
          ),
        ),
      ),
    );
  }
}

//bottom sheet
class RollOverBottomSheet extends StatefulWidget {
  const RollOverBottomSheet({Key? key}) : super(key: key);
  @override
  State<RollOverBottomSheet> createState() => _RollOverBottomSheetState();
}

class _RollOverBottomSheetState extends State<RollOverBottomSheet>
    with TickerProviderStateMixin {
  final _duration = Duration(milliseconds: 800);

  late AnimationController _animationcontroller;
  late Animation<double> _animateopacity;
  late Animation<double> _animateleft, _animatebottom;
  bool loaded = false;
  late TextEditingController _rolloveramounttextcontroller;
  late DashboardBloc _bloc;
  ClosingPaymentResponseData? data;
  DashboardResponseData Userdata =
      DashboardResponseData(IsRefrenceInAllowed: false);

  @override
  void initState() {
    _bloc = DashboardBloc();

    _bloc.GetPaymentRolloverStream.listen((event) {
      if (event.status == Status.COMPLETED) {
        DialogBuilder(context).hideLoader();
        setState(() {
          data = event.data;
          print(data?.toJson());
        });
        if (data?.IsProfileRolloverEnable == false) {
          Navigator.pop(context);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => RolloverPaymentAlert(
                      title: "Rollover Closed!",
                      message: "Rollover had been closed.")));
        } else if (data?.IsProfileRolloverEnable == true &&
            data?.RoRequestStatus == "Pending") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => RollOverTransectionSheet(
                      message: event.message,
                      title: "Your previous rollover request is still Pending.",
                      response: event.data ?? ClosingPaymentResponseData())));
        } else {
          setState(() {
            loaded = true;
          });
        }
      } else if (event.status == Status.ERROR) {
        DialogBuilder(context).hideLoader();
        //showSnackBar(context, event.message, true);
        Navigator.pop(context);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => RolloverPaymentAlert(
                    title: "Rollover Error!", message: event.message)));
      } else if (event.status == Status.LOADING) {
        DialogBuilder(context).showLoader();
      }
    });
    _bloc.GetPaymentRolloverData();

    _bloc.SavePaymentRolloverStream.listen((event) {
      print(jsonEncode(event.data));
      if (event.status == Status.COMPLETED) {
        DialogBuilder(context).hideLoader();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => RollOverTransectionSheet(
                message: event.message,
                title: "Rollover Request submitted sucessfully.",
                response: event.data),
          ),
        );
      } else if (event.status == Status.ERROR) {
        DialogBuilder(context).hideLoader();
        // showSnackBar(context, event.message, true);
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  RollOverTransectionSheet(message: event.message)),
        );
      } else if (event.status == Status.LOADING) {
        DialogBuilder(context).showLoader();
      }
    });
    _rolloveramounttextcontroller = TextEditingController();

    _rolloveramounttextcontroller.addListener(getLatestvalue);

    super.initState();

    _animationcontroller =
        AnimationController(vsync: this, duration: _duration);

    _animateopacity = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
            parent: _animationcontroller, curve: Curves.fastOutSlowIn));
    _animateleft = Tween<double>(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: _animationcontroller, curve: Curves.fastOutSlowIn));

    _animatebottom = Tween<double>(begin: -1.0, end: 0.0).animate(
        CurvedAnimation(
            parent: _animationcontroller, curve: Curves.fastOutSlowIn));
    _animationcontroller.forward();

    super.initState();
  }

  getLatestvalue() {
    setState(() {
      //_rollover_amount = data?.ClosingPayment ?? 0.0;
    });
  }

  @override
  void dispose() {
    _rolloveramounttextcontroller.dispose();
    _animationcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return AnimatedBuilder(
        animation: _animationcontroller.view,
        builder: (context, _) {
          if (!loaded) return Container();
          return Transform(
            transform: Matrix4.translationValues(
                0.0, _animatebottom.value * width, 0.0),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Container(
                height: height * 0.55,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF926AF6), Color(0xFFAC2EA3)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 15,
                    ),
                    Divider(
                      height: 4,
                      color: Colors.white,
                      endIndent: 150.w,
                      indent: 150.w,
                      thickness: 3.5,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Transform(
                      transform: Matrix4.translationValues(
                          0.0, _animateleft.value * width, 0.0),
                      child: AnimatedOpacity(
                        duration: _duration,
                        opacity: _animateopacity.value,
                        child: Text(
                          "All Rollover",
                          style: Theme.of(context)
                              .textTheme
                              .headline6!
                              .copyWith(
                                  fontSize: 18.sp,
                                  fontFamily: "Montserrat",
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Transform(
                            transform: Matrix4.translationValues(
                                0.0, _animateleft.value * width, 0.0),
                            child: AnimatedOpacity(
                              duration: _duration,
                              opacity: _animateopacity.value,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "Rs. ",
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6!
                                        .copyWith(
                                          fontSize: 20.sp,
                                          height: 2.0.h,
                                          fontFamily: "Montserrat",
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white,
                                        ),
                                  ),
                                  Text(
                                    Const.currencyFormatWithoutDecimal
                                        .format(data?.ClosingPayment ?? 0),
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6!
                                        .copyWith(
                                            fontSize: 36.sp,
                                            fontFamily: "Montserrat",
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(bottom: 08.0.h),
                                child: Transform(
                                  transform: Matrix4.translationValues(
                                      _animateleft.value * width, 0.0, 0.0),
                                  child: AnimatedOpacity(
                                    duration: _duration,
                                    opacity: _animateopacity.value,
                                    child: Padding(
                                      padding: EdgeInsets.only(left: 10.w),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Center(
                                            child: SizedBox(
                                              height: 22.h,
                                              width: 22.w,
                                              child: Image.asset(
                                                "assets/images/amount.png",
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 08.w,
                                          ),
                                          Text(
                                            "Amount",
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodySmall!
                                                .copyWith(
                                                  fontSize: 20.sp,
                                                  fontFamily: "Montserrat",
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white
                                                      .withOpacity(0.8),
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 04.h,
                              ),
                              AmountInputField(
                                Prefixtext: "Rs",
                                isBgColorWhite: true,
                                isenable: false,
                                textcontroller: _rolloveramounttextcontroller,
                                hint: data?.ClosingPayment.toString() ?? "0.0",
                                fontsize: 25.sp,
                                textColor: Colors.black,
                                color: [Colors.white, Colors.white],
                              ),
                            ],
                          ),
                          GestureDetector(
                            onTap: () {
                              var reqdata = ReceivePaymentReqData(
                                  transferAmount: 0,
                                  rolloverAmount: data?.ClosingPayment);
                              if (reqdata.rolloverAmount == 0.0 ||
                                  reqdata.rolloverAmount?.isFinite == false) {
                                showSnackBar(
                                    context,
                                    'Rollover amount must be a valid digit.',
                                    true);
                                return;
                              }
                              reqdata.source = AppModel().deviceID();
                              _bloc.SaveRollover(reqdata);
                            },
                            child: AnimatedLongButton(
                              text: "Send".toUpperCase(),
                              isBgColorWhite: true,
                              color: [Colors.white, Colors.white],
                            ),
                          ),
                          // AnimatedBottomBar()
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }

  RollOverTransectionSheet(
      {required String message,
      String? title,
      ClosingPaymentResponseData? response}) {
    return Transectiondetailwidget(
        // userID: Userdata.UserName,
        // date: DateTime.now().toString(),
        DateStr: response?.RoRequestDate ?? "",
        Title: title ?? "Rollover Request has been Processed",
        amountTypekey: "Rollover Amount",
        paymentTypekey: "Closing Payment",
        paymentTypevalue: Const.currencyFormatWithoutDecimal
            .format(response?.ClosingPayment ?? 0),
        amountTypevalue: Const.currencyFormatWithoutDecimal
            .format(response?.RoRequestAmount ?? 0),
        // _rollover_amount.toString(),
        onPressed: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => HideCapitalScreen(),
            ),
          );
        },
        color2: Color(0xFFB31E8E),
        color1: Color(0xFF8F71FF));
  }
}
