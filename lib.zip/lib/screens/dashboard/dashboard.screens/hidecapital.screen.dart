import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:theaccounts/bloc/dashboard_bloc.dart';
import 'package:theaccounts/model/DashboardResponse.dart';
import 'package:theaccounts/networking/ApiResponse.dart';
import 'package:theaccounts/networking/Endpoints.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/closingPayment.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/rollover.screen.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/withdrawbotttomsheet.dart';
import 'package:theaccounts/screens/widgets/GlowSetting.dart';
import 'package:theaccounts/screens/widgets/back_alert.dart';
import 'package:theaccounts/screens/widgets/loading_dialog.dart';
import 'package:theaccounts/utils/Const.dart';
import 'package:theaccounts/utils/shared_pref.dart';
import 'package:theaccounts/utils/utility.dart';
import '../custom.widgets/custom_widgets.dart';

class HideCapitalScreen extends StatefulWidget {
  HideCapitalScreen({Key? key}) : super(key: key);
  static const routeName = '/hidecapital-screen';

  @override
  State<HideCapitalScreen> createState() => _HideCapitalScreenState();
}

class _HideCapitalScreenState extends State<HideCapitalScreen>
    with TickerProviderStateMixin {
  final _duration = Duration(milliseconds: 500);
  final _d2 = Duration(milliseconds: 3500);

  late AnimationController _animController, _animationController;

  late AnimationController _revController;
  late Animation<double> _animleft, _revanimleft;
  late Animation<double> _opacity, _revopacity;

  late Image imagefromPref;

  loadImageFromPref() {
    SessionData().Loadimage().then((img) {
      setState(() {
        imagefromPref = SessionData().imagefrombase64String(img);
        CircleAvatar(
          radius: 40,
          child: imagefromPref,
        );
      });
    });
  }

  UpdateAniamtion() {
    setState(() {
      _animController = AnimationController(vsync: this, duration: _duration);

      _opacity = Tween<double>(begin: 0.5, end: 1.0).animate(
          CurvedAnimation(parent: _animController, curve: Curves.easeIn));
      _animleft = Tween<double>(begin: -0.6, end: 0.0).animate(
          CurvedAnimation(parent: _animController, curve: Curves.easeIn));

      _animController.forward();
    });
  }

  reverseAniamtion() {
    setState(() {
      _revController = AnimationController(vsync: this, duration: _duration);

      _revopacity = Tween<double>(begin: 0.5, end: 0.0).animate(
          CurvedAnimation(parent: _revController, curve: Curves.easeIn));
      _revanimleft = Tween<double>(begin: 0.0, end: -1.0).animate(
          CurvedAnimation(parent: _revController, curve: Curves.easeIn));

      _revController.forward();
    });
  }

  late DashboardBloc _bloc;
  DashboardResponseData? data;

  bool isShowCapital = false;
  bool firstload = true;
  @override
  void initState() {
    _bloc = DashboardBloc();
    _bloc.dashboardResponseStream.listen((event) {
      if (event.status == Status.COMPLETED) {
        DialogBuilder(context).hideLoader();
        setState(() {
          data = event.data;
          if (!firstload) isShowCapital = !isShowCapital;
          firstload = false;
        });
        print('from hide capital');
        print(data?.toJson());
        SessionData().setUserProfile(data);
      } else if (event.status == Status.ERROR) {
        DialogBuilder(context).hideLoader();
        showSnackBar(context, event.message, true);
      } else if (event.status == Status.LOADING) {
        DialogBuilder(context).showIndicator();
      }
    });
    _bloc.getDashboardData();

    _animController = AnimationController(vsync: this, duration: _duration);

    _animationController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 5000));
    _animationController.repeat(reverse: true);

    //_animController.reverse();
    _animController.forward();
    loadImageFromPref();

    UpdateAniamtion();
    reverseAniamtion();
    super.initState();
  }

  @override
  void dispose() {
    _animController.dispose();
    _revController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  bool isGlowOn = true;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return SafeArea(
      child: Scaffold(
        bottomNavigationBar: AnimatedBottomBar(),
        body: WillPopScope(
          onWillPop: () async {
            OnBackToLogout().Logout(
                ctx: context,
                title: "Confirmation Dialog",
                content: "Do You Want to Logout?");
            return true;
          },
          child: AnimatedBuilder(
            animation: _animController.view,
            builder: (context, child) {
              return Padding(
                padding: EdgeInsets.only(
                  left: 0.w,
                  right: 0.w,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Flexible(
                        flex: 04,
                        child: Container(
                            child: AnimatedTopBarTile(
                                notificationCount:
                                    data?.NotificationCount ?? 0))),
                    Flexible(
                      flex: 03,
                      child: Container(
                        // height: size.height * 0.14,
                        child: Padding(
                          padding: EdgeInsets.only(top: 06.0.h),
                          child: AnimatedTitle(
                              data: data,
                              trailing: AnimatedOpacity(
                                duration: _duration,
                                opacity: 1, //_opacity.value,
                                child: Container(
                                  width: 70.h,
                                  height: 70.h,
                                  alignment: Alignment.centerRight,
                                  decoration: BoxDecoration(
                                      // color: Color(0xFFAAA7A7),
                                      borderRadius: BorderRadius.circular(50)),
                                  child: Visibility(
                                      visible: true, // isShowCapital,
                                      child: FittedBox(
                                        child: CircleAvatar(
                                          radius: 50.h,
                                          backgroundImage: NetworkImage(
                                              // Endpoints.profilePicUrl +
                                              //     (data?.image ?? "")
                                              data?.image == null
                                                  ? Endpoints.noProfilePicUrl
                                                  : (Endpoints.profilePicUrl +
                                                      (data?.image ?? ""))),
                                        ),
                                      )),
                                ),
                              )),
                        ),
                      ),
                    ),
                    Flexible(
                      flex: 20,
                      child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            AnimatedSize(
                              curve: Curves.easeInBack,
                              duration: _duration,
                              child: SizedBox(
                                  height: !isShowCapital
                                      ? size.height * 0.09.h
                                      : 35.h),
                            ),
                            Bounce(
                              duration: Duration(milliseconds: 100),
                              onPressed: () {
                                if (isShowCapital) {
                                  setState(() {
                                    isShowCapital = false;
                                    print("size : $size.height");
                                  });
                                } else {
                                  _bloc.getDashboardData();
                                }
                              },
                              child: AnimatedContainer(
                                duration: _d2,
                                curve: !isShowCapital
                                    ? Curves.easeOut
                                    : Curves.easeIn,
                                child: !isShowCapital
                                    ? GlowSetting(
                                        radius: size.height < 700 ? 155 : 180,
                                        color:
                                            Color(0xff92298D).withOpacity(0.1),
                                        color1:
                                            Color(0xffBF40BF).withOpacity(0.7),
                                        child: Center(
                                          child: Text(
                                            "Show Capital",
                                            textAlign: TextAlign.center,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1!
                                                .copyWith(
                                                    fontSize: size.height < 700
                                                        ? 14.sp
                                                        : 18.sp,
                                                    fontWeight:
                                                        FontWeight.w500),
                                          ),
                                        ),
                                      )
                                    : GlowSetting(
                                        color:
                                            Color(0xff92298D).withOpacity(0.1),
                                        color1:
                                            Color(0xffBF40BF).withOpacity(0.7),
                                        radius: size.height < 700 ? 155 : 180,
                                        child: Text(
                                          "Hide Capital",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyText1!
                                              .copyWith(
                                                  fontSize: size.height < 700
                                                      ? 14.sp
                                                      : 18.sp,
                                                  fontWeight: FontWeight.w500),
                                        ),
                                      ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 10.0.h),
                              child: FittedBox(
                                child: Container(
                                    // height: size.height * 0.1.h,
                                    width: size.width.w,
                                    child: capitalAmountWidget(context, size)),
                              ),
                            ),
                            CustomAnimationsWidgets(
                              isreverse: !isShowCapital,
                              data: data,
                            )

                            // SizedBox(height: 18.h)
                          ],
                        ),
                      ),
                    ),
                    Spacer(flex: 01),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget capitalAmountWidget(BuildContext context, Size size) {
    double width = MediaQuery.of(context).size.width;
    return Transform(
      transform: Matrix4.translationValues(
          !isShowCapital ? _revanimleft.value * width : _animleft.value * width,
          0.0,
          // : _animleft.value * width,
          0.0),
      child: AnimatedOpacity(
        duration: _duration,
        opacity: !isShowCapital ? _revopacity.value : _opacity.value,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Rs.\t",
              style: Theme.of(context).textTheme.bodyText1!.copyWith(
                  height: size.height < 700 ? 1.5.h : 2.0.h,
                  fontSize: size.height < 700 ? 16.sp : 20.sp,
                  fontWeight: FontWeight.w800),
            ),
            Text(
              Const.currencyFormatWithoutDecimal
                  .format(data?.totalCapital ?? 0),
              style: Theme.of(context).textTheme.headline6!.copyWith(
                  fontSize: size.height < 700 ? 20.sp : 30.sp,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.bodyMedium!.color),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomAnimationsWidgets extends StatefulWidget {
  CustomAnimationsWidgets({Key? key, this.data, required this.isreverse})
      : super(key: key);
  final DashboardResponseData? data;
  final bool isreverse;
  @override
  State<CustomAnimationsWidgets> createState() =>
      _CustomAnimationsWidgetsState(data);
}

class _CustomAnimationsWidgetsState extends State<CustomAnimationsWidgets>
    with TickerProviderStateMixin {
  _CustomAnimationsWidgetsState(this.data);
  DashboardResponseData? data;
  final _duration = Duration(milliseconds: 1500);
  late AnimationController _animController, _revController;
  late Animation<double> _opacity; //, _revopacity;

  UpdateAniamtion() {
    setState(() {
      _animController = AnimationController(vsync: this, duration: _duration);

      _opacity = Tween<double>(begin: 0.5, end: 1.0).animate(
          CurvedAnimation(parent: _animController, curve: Curves.easeIn));

      _animController.forward();
    });
  }

  reverseAniamtion() {
    setState(() {
      _revController = AnimationController(vsync: this, duration: _duration);

      //_revopacity = Tween<double>(begin: 0.5, end: 0.0).animate(
      //        CurvedAnimation(parent: _revController, curve: Curves.easeIn));
//
      _revController.forward();
    });
  }

  @override
  void initState() {
    UpdateAniamtion();
    reverseAniamtion();
    print(data?.toJson());
    super.initState();
  }

  @override
  void dispose() {
    _animController.dispose();
    _revController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return AnimatedBuilder(
        animation: _animController.view,
        builder: (context, child) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                withdrawWidget(width, context),
                Spacer(flex: 1),
                closingPaymentWidget(context),
                Spacer(flex: 1),
                rolloverWidget(width, context),
              ],
            ),
          );
        });
  }

  Widget rolloverWidget(double width, BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (BuildContext context) => RollOverScreen()),
        );
      },
      child: AnimatedCircularButton(
          text: "All \nRollover",
          Icon: Center(
            child: SizedBox(
              height: 20.h,
              width: 20.h,
              child: Image.asset(
                "assets/images/rollover.png",
              ),
            ),
          ),
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          color: [Color(0xFF926AF6), Color(0xFFAC2EA3)]),
    );
  }

  AnimatedOpacity closingPaymentWidget(BuildContext context) {
    return AnimatedOpacity(
      duration: _duration,
      opacity: _opacity.value,
      child: GestureDetector(
        onTap: () {
          print("Pressesed.. Go to Transection Screen");
          // Navigator.of(context)
          //     .popUntil(ModalRoute.withName(HideCapitalScreen.routeName));
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (BuildContext context) => ClosingPaymentScreen()),
          );
        },
        child: AnimatedCircularButton(
            text: "Closing Payment",
            Icon: Center(
              child: SizedBox(
                height: 20.h,
                width: 20.h,
                child: Image.asset(
                  "assets/images/closing_payments.png",
                ),
              ),
            ),
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            color: [
              Color(0xffDA1467),
              Color(0xffFF992E),
            ]),
      ),
    );
  }

  Widget withdrawWidget(double width, BuildContext context) {
    return GestureDetector(
      onTap: () {
        print("Pressesed.. Go to withDraw Screen Layer");
        // Navigator.of(context)
        //     .popUntil(ModalRoute.withName(HideCapitalScreen.routeName));
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (BuildContext context) => WithDrawHoverLayerScreen()),
        );
      },
      child: AnimatedCircularButton(
        text: "Withdraw Capital",
        Icon: Center(
          child: SizedBox(
            height: 20.h,
            width: 20.h,
            child: Image.asset(
              "assets/images/withdraw.png",
            ),
          ),
        ),
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        color: [
          Color(0xFF2C7FFF),
          Color(0xFF6EFF98),
        ],
      ),
    );
  }
}
