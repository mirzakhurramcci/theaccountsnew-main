import 'package:flutter/material.dart';

class Error extends StatelessWidget {
  final String? errorMessage;
  final Function onRetryPressed;
  const Error({Key? key, this.errorMessage, required this.onRetryPressed})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            errorMessage ?? " Error",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.red,
              fontSize: 18,
            ),
          ),
          SizedBox(height: 8),
          OutlinedButton(
            child: Text(
              'Retry',
            ),
            onPressed: onRetryPressed(),
          )
        ],
      ),
    );
  }

  Dissmiss() {
    return Container(
      child: Text(errorMessage.toString()),
    );
  }
}
