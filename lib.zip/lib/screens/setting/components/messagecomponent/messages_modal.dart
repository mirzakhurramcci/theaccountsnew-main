class Message {
  String? name;
  String? message;
  bool isMine = false;

  Message({this.name, this.message, this.isMine = false});
}
