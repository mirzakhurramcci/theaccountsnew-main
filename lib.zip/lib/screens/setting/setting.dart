import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:theaccounts/model/DashboardResponse.dart';
import 'package:theaccounts/networking/Endpoints.dart';
import 'package:theaccounts/screens/dashboard/custom.widgets/custom_widgets.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/dashboard.dart';
import 'package:theaccounts/screens/dashboard/dashboard.screens/hidecapital.screen.dart';
import 'package:theaccounts/screens/loginprocess/loginscreens/main_setting.dart';
import 'package:theaccounts/screens/setting/message_screen.dart';
import 'package:theaccounts/screens/setting/profile_screen.dart';
import 'package:theaccounts/screens/setting/update_bank_details.dart';
import 'package:theaccounts/screens/setting/update_profile.dart';
import 'package:theaccounts/screens/widgets/back_alert.dart';
import 'package:theaccounts/utils/shared_pref.dart';

class SettingScreen extends StatefulWidget {
  const SettingScreen({Key? key}) : super(key: key);
  static const routeName = '/setting-screen';

  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  DashboardResponseData data =
      DashboardResponseData(IsRefrenceInAllowed: false);
  @override
  void initState() {
    super.initState();
    SessionData().getUserProfile().then(
          (value) => setState(() {
            data = value;
          }),
        );
  }

  /// Get from gallery

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    debugPrint("$size");
    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          Navigator.pushReplacementNamed(context, HideCapitalScreen.routeName);
          return true;
        },
        child: Scaffold(
          bottomNavigationBar: AnimatedBottomBar(),
          backgroundColor: Theme.of(context).backgroundColor,
          body: SingleChildScrollView(
            child: Container(
              height: size.height,
              width: size.width,
              child: Column(
                children: [
                  Flexible(
                    flex: 4,
                    child: TopWidgets(),
                  ),
                  // SizedBox(
                  //   height: 15.h,
                  // ),
                  Flexible(
                    flex: 9,
                    fit: FlexFit.tight,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          alignment: Alignment.center,
                          margin: EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                blurRadius: 18.h,
                                spreadRadius: 05.w,
                                offset: Offset(2.w, 3.h),
                              )
                            ],
                            borderRadius: BorderRadius.circular(25),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomCenter,
                              colors: [
                                // Color(0xffEEC32D),
                                // Color(0xffF6322A),
                                Color(0xff92298D),
                                Color(0xff92298D)
                              ],
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 5.h, horizontal: 12.w),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Container(
                                    height: size.height * 0.15.h,
                                    margin: EdgeInsets.all(4),
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: Colors.white,
                                          width: 2.w,
                                        )),
                                    child: GestureDetector(
                                      onTap: () {},
                                      child: CircleAvatar(
                                        radius: 40,
                                        backgroundImage: NetworkImage(
                                            data.image == null
                                                ? Endpoints.noProfilePicUrl
                                                : (Endpoints.profilePicUrl +
                                                    data.image.toString())),
                                      ),
                                    ),
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  child: ListTile(
                                    title: Center(
                                      child: Text(
                                        data.fullName ?? "",
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1!
                                            .copyWith(
                                              fontSize: 22.sp,
                                              color: Colors.white,
                                              fontWeight: FontWeight.w400,
                                            ),
                                      ),
                                    ),
                                    subtitle: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          data.UserName ?? "",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyText1!
                                              .copyWith(
                                                fontSize: 18.sp,
                                                color: Colors.white,
                                                fontWeight: FontWeight.w300,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 8.h,
                                ),
                                Flexible(
                                  flex: 1,
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30.w, vertical: 10.h),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    ProfileScreen(),
                                              ),
                                            );
                                          },
                                          child: SmallRadiusButton(
                                            text: "View Profile",
                                            color: [
                                              Color(0xFFFAFAFA),
                                              Color(0xFFFAFAFA)
                                            ],
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    MainSettings(),
                                              ),
                                            );
                                          },
                                          child: SmallRadiusButton(
                                            text: 'App Setting',
                                            color: [
                                              Color(0xFFFAFAFA),
                                              Color(0xFFFAFAFA)
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25.h,
                  ),
                  Flexible(
                    flex: 03,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Flexible(
                            flex: 08,
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => UpdateProfile(),
                                  ),
                                );
                              },
                              child: Cards(
                                width: size.width * 0.2.w,
                                title: 'Update Profile',
                                iconPath: "assets/images/update_profile.png",
                              ),
                            ),
                          ),
                          Spacer(
                            flex: 01,
                          ),
                          Flexible(
                            flex: 08,
                            child: GestureDetector(
                              //update bank detail-->
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => UpdateBankDetails(),
                                  ),
                                );
                              },
                              child: Cards(
                                title: 'Update Bank Details',
                                iconPath:
                                    "assets/images/update_bank_detail.png",
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 35.h,
                  ),
                  Flexible(
                    flex: 04,
                    child: Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.symmetric(horizontal: 12.w),
                      height: size.width * 0.50.h,
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: Theme.of(context).shadowColor,
                            blurRadius: 18.h,
                            spreadRadius: 05.w,
                            offset: Offset(2.w, 3.h),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pushReplacementNamed(
                                  context, DashBoardScreen.routeName);
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20.w, vertical: 08.h),
                              margin: EdgeInsets.symmetric(horizontal: 40.h),
                              decoration: BoxDecoration(
                                  color: Theme.of(context).shadowColor,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  SvgPicture.asset(
                                    'assets/svg/dashboard_icon.svg',
                                    height: 30.h,
                                    width: 30.w,
                                    color: Theme.of(context).dividerColor,
                                  ),
                                  Text(
                                    'Dashboard',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyText1!
                                        .copyWith(
                                          fontSize: 16.sp,
                                          fontWeight: FontWeight.w400,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.pushReplacementNamed(
                                  context, MessageScreen.routeName);
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20.w, vertical: 08.h),
                              margin: EdgeInsets.symmetric(horizontal: 40.w),
                              decoration: BoxDecoration(
                                  color: Theme.of(context).shadowColor,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  SvgPicture.asset(
                                    'assets/svg/msgs.svg',
                                    height: 30.h,
                                    width: 30.w,
                                    color: Theme.of(context).dividerColor,
                                  ),
                                  Text(
                                    'Messaging',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyText1!
                                        .copyWith(
                                          fontSize: 16.sp,
                                          fontWeight: FontWeight.w400,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30.h,
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  //
  Padding TopWidgets() {
    return Padding(
      padding: EdgeInsets.only(
          left: 18.0.h, right: 18.0.h, top: 30.h, bottom: 12.0.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () {
              OnBackToLogout().Logout(
                  ctx: context,
                  title: "Confirmation Dialog",
                  content: "Do You Want to Logout?");
            },
            child: SmallRadiusButton(
              text: "Log Out",
              textcolor: Colors.white,
              color: [
                Color(0xffB31E8E),
                Color(0xff92298D)
                // Color(0xff8F71FF),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.pushReplacementNamed(
                  context, HideCapitalScreen.routeName);
            },
            child: Padding(
              padding: EdgeInsets.only(left: 22.0.w),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                    color: Theme.of(context).backgroundColor,
                    //Theme.of(context).backgroundColor,
                    shape: BoxShape.circle),
                child: Image.asset(
                  'assets/images/arrow_back.png',
                  color: Theme.of(context).dividerColor,
                  height: 17.h,
                  width: 20.w,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Cards extends StatelessWidget {
  Cards({Key? key, required this.title, this.width, required this.iconPath})
      : super(key: key);
  final String title;
  final String iconPath;
  final double? width;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: 150.h,
      width: size.width * 0.4.w,
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor,
            blurRadius: 18.h,
            spreadRadius: 05.w,
            offset: Offset(2.w, 3.h),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            iconPath,
            height: 40.h,
            width: 40.w,
            color: Theme.of(context).dividerColor,
          ),
          Padding(
            padding: EdgeInsets.all(8.0.h),
            child: SizedBox(
              width: width ?? size.width * 0.3.w,
              child: Text(
                title,
                maxLines: 2,
                overflow: TextOverflow.visible,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyText1!.copyWith(
                      fontSize: 15.sp,
                      height: 1.5.h,
                      fontWeight: FontWeight.w400,
                    ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SmallRadiusButton extends StatelessWidget {
  const SmallRadiusButton({
    required this.text,
    this.color,
    this.textcolor,
    Key? key,
  }) : super(key: key);

  final String text;
  final Color? textcolor;
  final List<Color>? color;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.0.w, vertical: 00.h),
      height: 30.h,
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(100),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.4),
            blurRadius: 18.h,
            spreadRadius: 03.w,
            offset: Offset(2.w, 3.h),
          )
        ],
        gradient: LinearGradient(
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
          colors: color ??
              [
                // Color.fromARGB(255, 50, 167, 230),
                // Color.fromARGB(255, 194, 44, 231),
              ],
        ),
      ),
      child: Center(
        child: Text(
          text,
          style: Theme.of(context).textTheme.bodyText1!.copyWith(
                fontSize: 14.sp,
                color:
                    textcolor ?? Theme.of(context).textTheme.bodyText1!.color,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
    );
  }
}
