import 'package:flutter/material.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:theaccounts/bloc/dashboard_bloc.dart';
import 'package:theaccounts/model/CapitalHistoryResponse.dart';
import 'package:theaccounts/model/requestbody/HistoryReqBody.dart';
import 'package:theaccounts/networking/ApiResponse.dart';
import 'package:theaccounts/screens/dashboard/custom.widgets/custom_widgets.dart';
import 'package:theaccounts/screens/setting/components/setting.widgets.dart';
import 'package:theaccounts/screens/widgets/GlowSetting.dart';
import 'package:theaccounts/screens/widgets/loading_dialog.dart';
import 'package:theaccounts/utils/Const.dart';
import 'package:theaccounts/utils/utility.dart';

class LastDepositeScreen extends StatefulWidget {
  const LastDepositeScreen({Key? key}) : super(key: key);

  @override
  State<LastDepositeScreen> createState() => _LastDepositeScreenState();
}

class _LastDepositeScreenState extends State<LastDepositeScreen> {
  //late TextEditingController _searchtextcontroller;

  int pno = 0;
  late DashboardBloc _bloc;
  List<CapitalHistoryResponseData>? data;
  String Filter = "ALL";
  double totalCredit = 0;
  String LastDate = "";
  @override
  void initState() {
    _bloc = DashboardBloc();
    _bloc.CapitalHistoryStream.listen((event) {
      if (event.status == Status.COMPLETED) {
        DialogBuilder(context).hideLoader();
        setState(() {
          data = event.data;
          LastDate = data?[0].DateStr ?? "";
          totalCredit = data?[0].Credit ?? 0;
          // data?.forEach((element) {
          //   totalCredit += (element.Credit ?? 0);
          // });
        });
      } else if (event.status == Status.ERROR) {
        DialogBuilder(context).hideLoader();
        showSnackBar(context, event.message, true);
      } else if (event.status == Status.LOADING) {
        DialogBuilder(context).showLoader();
      }
    });
    _bloc.GetLastAddedAmountyData(HistoryReqData(duration: Filter, pno: pno));

    super.initState();
  }

  @override
  void dispose() {
    //_searchtextcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    Size size = MediaQuery.of(context).size;
    double height = MediaQuery.of(context).size.height;
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context);
        return true;
      },
      child: Scaffold(
        bottomNavigationBar: AnimatedBottomBar(),
        body: Container(
          height: height,
          width: width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Flexible(
                  flex: 01,
                  child: Padding(
                    padding: EdgeInsets.only(top: 24.0.h),
                    child: CustomTopBar(topbartitle: "Last Deposit"),
                  )),
              Flexible(
                flex: 6,
                child: Padding(
                  padding: EdgeInsets.all(12.0.h),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Spacer(
                        flex: 3,
                      ),
                      GlowSetting(
                        color:
                            Color.fromARGB(255, 90, 152, 190).withOpacity(0.1),
                        color1:
                            Color.fromARGB(255, 68, 182, 223).withOpacity(0.7),
                        radius: size.height < 700 ? 155 : 180,
                        child: Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text: 'Rs.  ',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1!
                                    .copyWith(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w600),
                              ),
                              TextSpan(
                                text: Const.currencyFormatWithoutDecimal
                                    .format(totalCredit),
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1!
                                    .copyWith(
                                        fontSize: 19.sp,
                                        fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Spacer(
                        flex: 1,
                      ),
                      Center(
                        child: Text(
                          LastDate.isNotEmpty ? LastDate : "---",
                          style:
                              Theme.of(context).textTheme.bodyText2!.copyWith(
                                    fontSize: 14,
                                  ),
                        ),
                      ),
                      Spacer(
                        flex: 2,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
